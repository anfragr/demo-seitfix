/* HUMANKIND: kleine Helfer fuer die Custom-Sections. Kein Framework, kein Build. */
(function () {
  var wurzel = document.documentElement;
  wurzel.classList.add('hk-js');

  var sparsam = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function einblenden(bereich) {
    var ziele = (bereich || document).querySelectorAll('.hk-auf:not(.hk-da)');
    if (!ziele.length) return;

    if (sparsam || !('IntersectionObserver' in window)) {
      ziele.forEach(function (el) {
        el.classList.add('hk-da');
      });
      return;
    }

    var beobachter = new IntersectionObserver(
      function (eintraege) {
        eintraege.forEach(function (e) {
          if (e.isIntersecting) {
            e.target.classList.add('hk-da');
            beobachter.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
    );

    ziele.forEach(function (el) {
      beobachter.observe(el);
    });
  }

  function laufbandFuellen(bereich) {
    var baender = (bereich || document).querySelectorAll('.hk-laufband__spur:not([data-hk-fertig])');
    baender.forEach(function (spur) {
      var satz = spur.querySelector('.hk-laufband__satz');
      if (!satz) return;
      // Zweiter Satz macht die Schleife nahtlos
      if (spur.children.length < 2) {
        spur.appendChild(satz.cloneNode(true));
      }
      spur.setAttribute('data-hk-fertig', 'true');
    });
  }

  function start(bereich) {
    laufbandFuellen(bereich);
    einblenden(bereich);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      start(document);
    });
  } else {
    start(document);
  }

  // Theme-Editor: Sections werden live neu geladen
  document.addEventListener('shopify:section:load', function (e) {
    start(e.target);
  });
  document.addEventListener('shopify:section:select', function (e) {
    start(e.target);
  });
})();
