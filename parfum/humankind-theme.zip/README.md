# HUMANKIND Theme

Shopify-Theme auf Basis von Dawn. Gebaut von Seitfix, Graz.

Dawn bleibt vollstaendig erhalten. Dazu kommt ein Design-Layer und sieben eigene
Sections. Alles, was Shopify an Shop-Logik mitbringt, funktioniert unveraendert:
Warenkorb, Varianten, Rabattcodes, Checkout, Kundenkonten, Barrierefreiheit.

---

## Was neu ist

**Dateien, die dazugekommen sind**

| Datei | Zweck |
|---|---|
| `assets/humankind.css` | Kompletter Design-Layer. Farben, Typografie, alle Section-Styles. |
| `assets/humankind.js` | Scroll-Einblendung und die nahtlose Schleife im Laufband. Kein Framework. |
| `sections/hk-video-hero.liquid` | Video-Hero mit Overlay, Ueberschrift, Buttons |
| `sections/hk-laufband.liquid` | Endlos laufendes Band mit Begriffen |
| `sections/hk-statement.liquid` | Durchgestrichene Zeilen plus Aussage, Strich zeichnet sich beim Scrollen |
| `sections/hk-kaufblock.liquid` | Kaufblock mit Varianten, Probe-Button und Vertrauenspunkten |
| `sections/hk-duftpyramide.liquid` | Kopf-, Herz- und Basisnote |
| `sections/hk-zitat.liquid` | Grosses Zitat |
| `sections/hk-werte.liquid` | Werte-Kacheln |

**Dateien, die geaendert wurden**

- `layout/theme.liquid`: drei Zeilen fuer Schriften, CSS und JS. Sonst unveraendert.
- `templates/index.json`: Startseite aus den neuen Sections zusammengesetzt.
- `templates/product.json`: Laufband, Duftpyramide und Werte unter der Produktseite.
- `config/settings_data.json`: Farbschemata, Radien, Warenkorb als Drawer.
- `config/settings_schema.json`: Theme-Name und Autor.

Alles andere ist unangetastetes Dawn.

---

## Apps

Kurz: alle Shopify-Apps funktionieren.

- **App Embeds** (Reviews, Popups, Tracking-Pixel, Wishlist, Cookie-Banner):
  brauchen nur `{{ content_for_header }}` im `theme.liquid`. Ist da, unveraendert.
- **App Blocks** (Bewertungssterne, Groessentabellen, Bundle-Widgets, Trust-Badges):
  jede eigene Section akzeptiert sie. Im schema steht `{ "type": "@app" }`,
  im Template werden sie mit `{% render block %}` ausgegeben. Im Theme-Editor
  erscheinen sie unter „Block hinzufuegen".
- **Checkout-Apps** (Zahlung, Versand, Rabatte, Steuern): laufen komplett
  ausserhalb vom Theme.
- **Alte Apps mit Snippet-Anleitung** („fueg diesen Code in product.liquid ein"):
  gehen auch, brauchen aber wie in jedem Theme einen manuellen Handgriff.

Der Kaufblock nutzt Dawns `<product-form>`. Damit sehen Analytics, Upsell-Apps
und der Warenkorb-Drawer den Add-to-Cart genauso wie auf der normalen
Produktseite. Kein Sonderweg, keine blinden Flecken im Tracking.

---

## Einrichten

### 1. Dev-Store anlegen

Kostenlos ueber einen Shopify-Partner-Account auf `partners.shopify.com`.
Dev-Stores sind gratis, nur das Passwort-Gate bleibt aktiv, bis der Store auf
einen Tarif geht.

### 2. Theme hochladen

**Variante A, ohne Terminal**

Onlineshop → Themes → Hinzufuegen → ZIP-Datei hochladen. Danach
„Veroeffentlichen".

**Variante B, mit Shopify CLI (empfohlen zum Weiterarbeiten)**

```bash
npm install -g @shopify/cli@latest
cd humankind-theme
shopify theme dev --store dein-store.myshopify.com
```

`shopify theme dev` startet eine lokale Vorschau, die bei jeder Dateiaenderung
sofort neu laedt. Wenn es passt:

```bash
shopify theme push
```

### 3. Produkte anlegen

Zwei Produkte reichen fuer den Start:

1. **HUMANKIND Eau de Parfum**, 99 €, Variante „50 ml".
   Weitere Groessen einfach als weitere Varianten anlegen, der Kaufblock zeigt
   sie automatisch als Auswahl.
2. **HUMANKIND Probe 2 ml**, 5 €. Bestand hoch setzen oder Bestandsverfolgung
   ausschalten.

### 4. Startseite verbinden

Onlineshop → Themes → Anpassen. Dann:

- **HK Video-Hero**: unter „Video" das Hero-Video auswaehlen.
  Vorher hochladen unter Inhalte → Dateien. `hero.mp4` aus dem Demoordner passt.
- **HK Kaufblock**: unter „Produkt" das Hauptprodukt waehlen, unter
  „Probe-Produkt" das Sample. Ohne Produkt zeigt der Block einen Hinweis.
- **Buttons im Hero**: Link auf den Kaufblock setzen. Der Anker ist `#hk-kaufen`.

### 5. Pflichtseiten fuer Oesterreich

Vor dem Livegang anlegen unter Onlineshop → Seiten und im Footer verlinken:

- Impressum (§ 5 ECG, § 24 MedienG)
- Datenschutzerklaerung
- AGB
- Widerrufsbelehrung mit Muster-Widerrufsformular
- Versand und Lieferung
- Zahlungsarten

Shopify erzeugt unter Einstellungen → Richtlinien Rohfassungen fuer AGB,
Datenschutz, Widerruf und Versand. Die sind ein Startpunkt, kein fertiger Text.
Beim Impressum hilft der Impressum-Generator der WKO.

---

## Farben und Schriften aendern

**Farben**: Onlineshop → Themes → Anpassen → Theme-Einstellungen → Farben.
Fuenf Schemata sind vorbelegt:

| Schema | Verwendung |
|---|---|
| scheme-1 | Weiss auf Tinte, Standard |
| scheme-2 | Creme, fuer Kaufblock und Pyramide |
| scheme-3 | Gold |
| scheme-4 | Nacht, fuer das Laufband |
| scheme-5 | Nacht mit Goldverlauf |

Die Markenfarben stecken zusaetzlich als Variablen ganz oben in
`assets/humankind.css`. Wer den Goldton global aendern will, aendert dort
`--hk-gold`.

**Schriften**: Playfair Display und Inter kommen von Google Fonts, geladen in
`layout/theme.liquid`. Wer stattdessen Shopify-Schriften will (schneller, keine
externe Anfrage, im Editor umstellbar), aendert in `assets/humankind.css`:

```css
--hk-serif: var(--font-heading-family);
--hk-sans: var(--font-body-family);
```

und entfernt den Google-Fonts-Link aus `theme.liquid`.

---

## Bekannte Stellen zum Nachjustieren

- Das Hero-Video braucht ein Poster-Bild fuer langsame Verbindungen. Shopify
  erzeugt eines automatisch, ein eigenes ist besser. Feld „Bild als Alternative".
- Das Laufband pausiert beim Hovern und steht still, wenn im Betriebssystem
  „Bewegung reduzieren" aktiv ist.
- Der Kaufblock zeigt beim Varianten-Radio den Preis pro Variante. Der Preis im
  Button bleibt der Startpreis. Bei mehreren Groessen mit stark
  unterschiedlichen Preisen ist es sauberer, den Preis aus dem Button zu
  entfernen und nur die Radios sprechen zu lassen.
- Der Duft heisst im Theme durchgehend HUMANKIND. Die alte SPEKTRUM-Fassung aus
  der Demoseite ist nicht uebernommen.
